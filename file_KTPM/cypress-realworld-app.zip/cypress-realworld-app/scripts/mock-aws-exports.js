// mock aws-exports.js

const awsmobile = {
  aws_cognito_region: "",
  aws_user_pools_id: "",
};

export default awsmobile;
